// imports
import 'bootstrap/dist/css/bootstrap.min.css'; // default bootsrap styling

// main logic/code
