export const budget = [1100, 400, 400, 250, 300];
